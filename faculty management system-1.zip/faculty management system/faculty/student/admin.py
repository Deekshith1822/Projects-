from django.contrib import admin
from student.models import *
admin.site.register(faculty)

# Register your models here.
